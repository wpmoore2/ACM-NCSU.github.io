import csv
import numpy as np
import matplotlib.pyplot as plt


with open('', 'r') as f:
  reader = csv.reader(f)
  your_list = list(reader)

#assign your list to a new numpy array

#Part 1: plot either African American, Hispanic, or Native American statistics
plt.figure(1)

plt.scatter(x,y)
plt.xlabel("")
plt.ylabel("")
plt.title("")
plt.show()

#Part 2: try plotting two races in the same graph
plt.figure(2)


#Part 3: plot a pie graph of all races using a for loop to total enrollment across the 16 years
plt.figure(3)

#boilerpoint code for pie chart
labels = 'Black', 'Hispanic', 'Native', 'Other'
fracs = []
colors = ['gold', 'yellowgreen', 'lightcoral', 'lightskyblue']
explode = (0.1, 0, 0, 0)
plt.pie(fracs, explode=explode, labels=labels, colors=colors,autopct='%1.1f%%', shadow=True, startangle=140)
plt.title("Percent of Minorities in Engineering Over 15 Years")
plt.axis('equal')
plt.show()

#if you have finished all other tasks, try to plot something even more creative or ask to move on to exercise 2