import csv
import numpy as np
import matplotlib.pyplot as plt


with open('NC_PublicSchool.csv', 'r') as f:
  reader = csv.reader(f)
  ps_list = list(reader)

with open('NCSU_ENGR.csv', 'r') as f:
  reader = csv.reader(f)
  ncsu_list = list(reader)

#choose a field from ps_list and plot it against statistics from ncsu_list


