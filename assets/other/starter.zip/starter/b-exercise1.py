import csv
import numpy as np
import matplotlib.pyplot as plt


with open('NCSU_ENGR.csv', 'r') as f:
  reader = csv.reader(f)
  your_list = list(reader)

#assign your list to a new numpy array

#Part 1: plot either African American, Hispanic, or Native American statistics
plt.figure(1)
x = []
y = []
plt.scatter(x,y)
plt.xlabel("")
plt.ylabel("")
plt.title("")
plt.show()

#Part 2: try plotting two races in the same graph
plt.figure(2)
z = []

#Part 3: plot a pie graph using a for loop to total enrollment for all demographics
plt.figure(3)
w = []
v = []

#initialize some variables to store total enrollement for each demographic

#create some for loops to total the enrollement into each variable

#boilerpoint code for pie graph, just need to update frac to include variable names
labels = 'Black', 'Hispanic', 'Native', 'Other'
fracs = []
colors = ['gold', 'yellowgreen', 'lightcoral', 'lightskyblue']
explode = (0.1, 0, 0, 0)
plt.pie(fracs, explode=explode, labels=labels, colors=colors,autopct='%1.1f%%', shadow=True, startangle=140)
plt.title("Percent of Minorities in Engineering Over 15 Years")
plt.axis('equal')
plt.show()

#if you have finished all other tasks, try to plot something even more creative or ask to move on to exercise 2