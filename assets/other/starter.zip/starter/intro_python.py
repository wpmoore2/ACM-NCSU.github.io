import numpy as np

a = np.array([[ 0,  1,  2,  3],
       [10, 11, 12, 13],
       [20, 21, 22, 23],
       [30, 31, 32, 33],
       [40, 41, 42, 43]])

b = np.array([ 1, 11, 21, 31])

#find and print the index of 22 in array a

#create a for loop to print the values in array b

#print the multiplication of the first row of a by b
